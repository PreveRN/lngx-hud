# lngx-hud

HUD status (health, armor, hunger, thirst, stress, stamina, oxygen, premium) + speedometer + minimap (square/circle).
Support **ESX, QBCore, Qbox** (auto-detect) dan standalone. Ringan: satu thread, interval adaptif, data dikirim ke NUI hanya saat berubah.

## Install
1. Taruh folder `lngx-hud` di `resources`, lalu `ensure lngx-hud` (setelah framework & script bensin).
2. Hapus resource lama `bd-hud` / HUD lain agar tidak bentrok.
3. Edit `config.lua` (framework, posisi dock, bensin, dll).
   - Resource framework di-rename (mis. ESX jadi `ac-core`)? Ubah `Config.Resources.esx`.

## Sumber data
- ESX: `esx_status:onTick` (hunger, thirst, stress)
- QBCore / Qbox: metadata player via `QBCore:Player:SetPlayerData` (+ sinkron 10 detik)
- Health, armor, stamina, oxygen, speed, gear, rpm, engine: native
- Bensin: statebag `fuel` (ox_fuel dll) -> LegacyFuel / cdn-fuel / ps-fuel -> native
- Cruise control: bawaan (tombol Caps Lock, `Config.Cruise`), ikon di speedometer
- Sabuk: bawaan (tombol B, `Config.Seatbelt`, suara di `html/sounds/`, volume `Config.Seatbelt.Volume`), status di `LocalPlayer.state.seatbelt`. Pakai script sabuk lain? set `Config.Seatbelt.Enabled = false` lalu isi statebag / export `setSeatbelt`

## Exports (client)
```lua
exports['lngx-hud']:setVisible(true|false)
exports['lngx-hud']:isVisible()
exports['lngx-hud']:toggle()
exports['lngx-hud']:openSettings()
exports['lngx-hud']:setStat('stress', 40)     -- nil = lepas nilai manual (hunger/thirst/stress)
exports['lngx-hud']:setPremium(240)            -- jam tersisa | true = "VIP" | nil/false = sembunyi
exports['lngx-hud']:setSeatbelt(true|false|nil)
exports['lngx-hud']:isSeatbelt()
exports['lngx-hud']:setMapShape('square'|'circle')
exports['lngx-hud']:getMapShape()
exports['lngx-hud']:isCruise()
exports['lngx-hud']:setCruise(true|false)
exports['lngx-hud']:getFramework()
```
Event setara: `lngx-hud:setVisible`, `lngx-hud:setStat`, `lngx-hud:setPremium`, `lngx-hud:setSeatbelt`.

## Command
- `/lngx-hud` = alias cadangan menu pengaturan jika `/hud` bentrok dengan resource lain.
- `/hud` membuka menu pengaturan HUD (tampil/sembunyi HUD, ikon status, speedometer, satuan, lokasi, navigasi, bentuk & mode minimap, suara + volume; tersimpan per-pemain, ada tombol Reset), `/mapshape square|circle` ganti bentuk minimap (bisa dimatikan di config).

## Bahasa (locale JSON)
Semua teks (menu `/hud`, Admin HUD, speedometer, notifikasi sabuk / cruise, pesan admin) ada di `locales/<kode>.json`.
- Pilih bahasa: `Config.Language = 'id'` (tersedia `id`, `en`).
- Tambah bahasa baru: salin `locales/id.json` menjadi `locales/<kode>.json`, terjemahkan isinya (jangan ubah key), lalu set `Config.Language = '<kode>'`.
- Key `ui.*` dipakai NUI, key lainnya dipakai notifikasi Lua. Key yang belum diterjemahkan otomatis memakai bahasa `id`.
- Teks di `Config.Seatbelt.Messages` / `Config.Cruise.Messages` (jika diisi) tetap menimpa locale.
- Format angka uang tetap diatur `Config.PlayerInfo.Locale` (mis. `id-ID`).
- Setelah edit JSON: `restart lngx-hud`.

## Cruise control
Saat melaju (>= `Config.Cruise.MinSpeed`), tekan tombol cruise (default **Caps Lock**, bisa diubah di Settings > Key Bindings > FiveM, atau `/lngx-cruise`) untuk mengunci kecepatan. Ikon hijau di speedometer = aktif. Batal otomatis saat rem / rem tangan, mesin mati, keluar kendaraan, mundur, atau tabrakan.

## Gaya speedometer: klasik, bulat, atau bensin
Pemain memilih di `/hud` > Speedometer > **Gaya speedometer**: **Bulat** (dial RPM 36 segmen putih -> merah, gear, angka kecepatan, ikon sabuk / cruise / lampu / mesin / bensin di bawahnya), atau **Bensin** (kolom bensin 10 segmen di kiri, angka kecepatan besar, bar RPM 28 segmen, ikon sabuk / cruise + kecepatan kunci / lampu / mesin). Default server: `Config.SpeedoStyle` (`'classic'` / `'round'` / `'petrol'`). Pilihan tersimpan per-pemain. Gaya bulat & bensin tidak menampilkan navigasi waypoint (hanya ada di gaya klasik). Preview di browser: `html/index.html#round` / `#petrol`. Font Orbitron dimuat dari Google Fonts (fallback Consolas bila offline).

## Speedometer pesawat & helikopter
Saat pemain mengemudi pesawat (class 16) atau helikopter (class 15), speedometer mobil otomatis diganti HUD pesawat: pita heading, ALT (feet), KNOT + Mach, horizon buatan (pitch/roll) + VS (fpm), throttle, bahan bakar, roda pendarat, flaps, dan peringatan STALL. Pengaturan di `Config.Plane` (kelas kendaraan, interval, batas stall, `InvertRoll` kalau horizon miring ke arah yang salah). Ikut tombol "Tampilkan speedometer" di menu `/hud`; satuan pesawat selalu knot / feet / fpm.
- Flaps tidak punya native di GTA: default diestimasi dari kecepatan (`Config.Plane.AutoFlaps`). Script flaps sendiri: `exports['lngx-hud']:setPlaneFlaps(0-3)` (nil = kembali ke estimasi).
- Helikopter memakai HUD yang sama (`Config.Plane.Classes = { 15, 16 }`): tanpa roda/flaps/Mach/STALL, dial knot skala 200. Hapus `15` dari daftar kalau heli mau pakai speedometer mobil.
- Garis GPS lurus ke waypoint (garis pink menyambung di minimap & peta pause; `Config.FlightPath.Mode = 'dots'` untuk titik-titik) dibuat `client/flightpath.lua`, karena GPS bawaan GTA tidak menggambar rute saat terbang. Atur di `Config.FlightPath`.
- Navigasi GPS (panah arah + jarak ke waypoint + nama area tujuan) tampil di sebelah kanan pita heading saat waypoint dipasang. Ikut `Config.Nav` dan tombol Navigasi di `/hud`; jarak "TIBA" diatur `Config.Plane.NavArrival`.
- Ikon sabuk & cruise ada di bawah dial KNOT: hijau = aktif / dipakai, merah kedip = sabuk belum dipakai saat bergerak, redup = mati. Matikan lewat `Config.Plane.Seatbelt` / `Config.Plane.Cruise`.
- Sabuk di pesawat/heli: tombol sama dengan mobil (default **B**). Saat dipakai, pemain tidak bisa keluar kendaraan; terlempar saat tabrakan hanya jika `Config.Plane.EjectOnCrash = true`.
- Cruise di pesawat/heli = speed hold (kecepatan terkunci). Hanya bisa diaktifkan saat terbang (min `CruiseMinHeight`, `CruiseMinSpeed` / `CruiseMinSpeedHeli` knot) dengan tombol cruise (default **Caps Lock**). Batal otomatis saat throttle-down / rem ditekan, mesin mati, mendarat, atau menabrak.
- Throttle dibaca dari RPM mesin pesawat; roda dari `GetLandingGearState`.
- Preview di browser: buka `html/index.html#plane` atau `html/index.html#heli`. Kode UI-nya ada di bagian akhir `html/style.css` dan `html/script.js`.
- Teks UI ada di locales (`ui.plane.*`).

## Catatan
- Dock status berada di bawah minimap. Blip di minimap disembunyikan lewat `Config.HideMapBlips` / `HidePlayerBlip`. Geser lewat `Config.HudPosition`.
-

## Nama jalan per bentuk minimap
Minimap kotak memakai kotak nama lokasi (menempel di atas minimap), minimap lingkaran memakai pil nama jalan terpisah yang menempel di tepi atas lingkaran. Posisi diatur di `Config.LocationPosition.square` / `.circle` (`overlap` = seberapa menimpa lingkaran).

Menyetel posisi nama jalan langsung di game: `/locpos overlap 24`, `/locpos left 50`, atau `/locpos 42 280 291 24` (left bottom width overlap). Nilai akhir tercetak di konsol F8, salin ke `Config.LocationPosition`.

Minimap lingkaran memakai nama jalan melengkung (`style = 'arc'`) yang mengelilingi sisi atas minimap. Pas-kan di game dengan `/locpos ry 100`, `/locpos gap 4`, `/locpos left 50`, `/locpos bottom 285`, atau ganti ke pil dengan `/locpos style pill`.

## Border minimap
Bingkai di sekeliling minimap (kotak = persegi panjang bersudut, lingkaran = elips), digambar di luar area peta sehingga tidak menutupi peta. Diatur di `Config.MapBorder` (tebal, warna, glow, bayangan, posisi/ukuran per bentuk). Pemain bisa on/off lewat menu `/hud` > Border minimap. Border otomatis ikut hilang saat minimap disembunyikan / pause menu.

Pas-kan posisi langsung di game: `/mapborder left 30`, `/mapborder bottom 70`, `/mapborder width 312`, `/mapborder height 198`, `/mapborder radius 8`, `/mapborder thick 3`. Nilai akhir tercetak di konsol F8, salin ke `Config.MapBorder`.

## Admin HUD (/adminhud)
Panel tuner live (slider + input angka) untuk **posisi nama jalan** (kiri, bawah, lebar, tinggi & lebar lengkung untuk minimap bulat, gaya arc/pil) dan **border minimap** (kiri, bawah, lebar, tinggi, tebal, sudut). Bisa ganti bentuk minimap langsung dari panel. Tombol **Salin config** menyalin nilai siap tempel untuk `Config.LocationPosition` & `Config.MapBorder` (juga tercetak di F8); **Reset** kembali ke nilai `config.lua`. Tombol **Selesai** menyimpan permanen: disimpan di data server (tetap ada setelah server di-restart), ikut ditulis ke `config.lua` (cadangan lama di `config.lua.bak`), dan langsung diterapkan ke semua pemain online; pemain yang join/restart resource otomatis menerima layout tersimpan. Layout tersimpan di data server menimpa nilai `config.lua` -- untuk kembali ke nilai `config.lua`, tekan Reset lalu Selesai. Tombol X / Esc menutup tanpa menyimpan.

Izin: hanya pemain dengan group admin framework (`Config.AdminHud.Groups`, default `admin`, `superadmin`, `god`) di ESX / QBCore / Qbox. Command diatur di `Config.AdminHud.Command`.

## Brand server (nama + logo)
Nama dan logo terpisah, posisi & ukurannya diatur sendiri-sendiri:
- `Config.ServerBrand` = pil nama server: `Name`, `Subtitle`, `Position`, `X/Y`.
- `Config.ServerLogo` = logo berdiri sendiri: `File`, `Size` (tinggi px, bebas dibesarkan), `Round`, `Position`, `X/Y`.
Ganti logo dengan menimpa `html/logo.png` (atau taruh file lain di `html/` lalu set `File`). `Enabled = false` untuk mematikan masing-masing.

## Info pemain (ID, job, cash, bank)
Panel terpisah dari dock status, diatur di `Config.PlayerInfo`: posisi (`Position`, `X`, `Y`), simbol uang (`Currency`), format angka (`Locale`), dan baris apa saja yang tampil (`Show`: id, job, cash, bank, black).
ESX: job + akun `money` / `bank` / `black_money`. QBCore/Qbox: job + `cash` / `bank` (uang kotor tidak tampil jika tidak ada). Update instan lewat event framework. Pemain bisa menyembunyikannya di `/hud`.
(Panel info pemain: tiap item — ID, job, cash, bank, uang kotor — berupa kartu terpisah dengan background sendiri.)

## Gaya status: bulat atau garis
Pemain memilih gaya di `/hud` > Umum > **Gaya status**: **Bulat** (dock ikon dengan ring) atau **Garis** (bar tipis ala GTA V). Hanya satu gaya tampil sekaligus. Default server: `Config.StatusStyle` (`'ring'` / `'line'`).
- Gaya garis: baris 1 = darah + vest, baris 2 = lapar + haus (2 kotak, sama besar dengan baris 1), baris 3 (tipis) = stres, stamina, oksigen. Vest selalu tampil, stres hilang saat 0, stamina & oksigen hanya muncul saat terpakai; garis yang hilang membuat sisanya melebar. Pengaturan: `Config.LineHud`.
- Saklar per-status di menu `/hud` (Darah, Armor, dst) berlaku untuk kedua gaya.
- `Config.LineHud.Enabled = false` mematikan gaya garis total.

## Ikon senjata (v2.8.0)

Saat pemain memegang senjata, HUD menampilkan ikon jenis senjata (pistol, SMG, rifle, MG, shotgun, sniper, heavy, melee, thrown, tool), nama senjata, dan peluru (magazen / cadangan). Angka magazen berubah merah saat hampir habis.

- Pengaturan: `Config.Weapon` di `config.lua` (posisi, tick, nama/ikon kustom untuk senjata addon, daftar senjata yang disembunyikan).
- Pemain bisa menyembunyikannya lewat `/hud` > Umum > "Tampilkan ikon senjata".
- File baru: `client/weapon.lua`. Perubahan lain: `html/index.html`, `html/style.css`, `html/script.js`, `client/settings.lua`, `client/minimap.lua`, `client/main.lua`, `locales/*.json`.

## Vehicle Control (/vehmenu)
Menu kontrol kendaraan: mesin, lampu (mati / dekat / jauh), hazard, lampu dalam, kunci, 4 pintu, kap mesin, bagasi, 4 jendela, pindah kursi.
- Target: kendaraan yang sedang dikendarai, atau kendaraan terdekat (`Config.VehicleControl.Range`) jika di luar. Pindah kursi hanya dari dalam kendaraan.
- Command `/vehmenu` (ubah di `Config.VehicleControl.Command`), tombol bisa diatur lewat `Config.VehicleControl.Key` atau Settings > Key Bindings > FiveM.
- Exports: `exports['lngx-hud']:openVehicleControl()` dan `closeVehicleControl()`.
- Demo di browser: buka `html/index.html#vehicle`.



## UI (React)
Sumber UI ada di `web/` (React + esbuild), hasil build ada di `html/` (`index.html` + `assets/index.js` + `assets/index.css`) dan sudah siap pakai.
```
cd web
npm install
npm run build   # build sekali -> ../html
npm run dev     # rebuild otomatis; buka html/index.html di browser = mode demo
```
Mode demo (browser biasa): `index.html#settings`, `#admin`, `#round`, `#petrol`, `#plane`, `#heli`, `#vehicle`.
File lain di `html/` (logo, `sounds/`, `weapons/`) tidak disentuh build.
